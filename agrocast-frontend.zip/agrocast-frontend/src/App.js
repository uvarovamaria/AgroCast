// src/App.jsx
import React, { useState } from "react";
import {
  LineChart,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
} from "recharts";
import "./App.css";

const API_BASE_URL = "http://127.0.0.1:8000/api/v1";

function App() {
  const [lat, setLat] = useState(47.2313);
  const [lon, setLon] = useState(39.7233);
  const [scaleMonths, setScaleMonths] = useState(3);
  const [historyYears, setHistoryYears] = useState(5);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    setResult(null);

    try {
      const params = new URLSearchParams({
        lat: String(lat),
        lon: String(lon),
        scale_months: String(scaleMonths),
        history_years: String(historyYears),
      });

      const response = await fetch(`${API_BASE_URL}/spi/by-coords?${params}`);

      if (!response.ok) {
        const text = await response.text();
        throw new Error(
          `Ошибка ${response.status}: ${text || "не удалось получить данные"}`
        );
      }

      const data = await response.json();
      setResult(data);
    } catch (err) {
      console.error(err);
      setError(err.message || "Произошла ошибка при запросе SPI");
    } finally {
      setLoading(false);
    }
  };

  const historyData =
    result?.history?.map((item) => ({
      // ожидаем формат date: "2021-02-23", spi: число
      date: item.date,
      spi: item.spi,
    })) || [];

  return (
    <div className="app-root">
      <header className="app-header">
        <h1>AgroCast — SPI по координатам</h1>
        <p className="app-subtitle">
          Минимальный интерфейс для расчёта индекса засухи (SPI) по точке.
        </p>
      </header>

      <main className="app-main">
        <section className="card form-card">
          <h2>Параметры расчёта</h2>
          <form onSubmit={handleSubmit} className="spi-form">
            <div className="form-row">
              <label>
                Широта (lat)
                <input
                  type="number"
                  step="0.000001"
                  value={lat}
                  onChange={(e) => setLat(e.target.value)}
                  required
                />
              </label>
              <label>
                Долгота (lon)
                <input
                  type="number"
                  step="0.000001"
                  value={lon}
                  onChange={(e) => setLon(e.target.value)}
                  required
                />
              </label>
            </div>

            <div className="form-row">
              <label>
                Окно SPI, месяцев (scale_months)
                <input
                  type="number"
                  min="1"
                  max="24"
                  value={scaleMonths}
                  onChange={(e) => setScaleMonths(e.target.value)}
                  required
                />
              </label>
              <label>
                Лет истории (history_years)
                <input
                  type="number"
                  min="1"
                  max="50"
                  value={historyYears}
                  onChange={(e) => setHistoryYears(e.target.value)}
                  required
                />
              </label>
            </div>

            <button type="submit" className="btn" disabled={loading}>
              {loading ? "Считаем..." : "Получить SPI"}
            </button>
          </form>

          {error && <div className="error-box">{error}</div>}
        </section>

        {result && (
          <>
            <section className="card result-card">
              <h2>Текущий индекс SPI</h2>
              <div className="result-summary">
                <div>
                  <span className="result-label">Координаты:</span>{" "}
                  <span className="result-value">
                    {result.lat?.toFixed?.(4) ?? lat},{" "}
                    {result.lon?.toFixed?.(4) ?? lon}
                  </span>
                </div>
                <div>
                  <span className="result-label">Период сглаживания:</span>{" "}
                  <span className="result-value">
                    {result.scale_months ?? scaleMonths} мес.
                  </span>
                </div>
                <div>
                  <span className="result-label">Дата конца периода:</span>{" "}
                  <span className="result-value">
                    {result.end_date ?? "—"}
                  </span>
                </div>
                <div>
                  <span className="result-label">SPI:</span>{" "}
                  <span className="result-value result-value--spi">
                    {result.spi?.toFixed
                      ? result.spi.toFixed(2)
                      : String(result.spi)}
                  </span>
                </div>
                <div>
                  <span className="result-label">Категория:</span>{" "}
                  <span className="result-value result-value--category">
                    {result.category ?? "—"}
                  </span>
                </div>
              </div>

              {result.advice && (
                <div className="advice-box">
                  <h3>Рекомендации</h3>
                  <p>{result.advice}</p>
                </div>
              )}
            </section>

            <section className="card">
              <h2>История SPI</h2>

              {historyData.length === 0 ? (
                <p>Исторических данных нет.</p>
              ) : (
                <>
                  <div className="chart-wrapper">
                    <ResponsiveContainer width="100%" height={280}>
                      <LineChart data={historyData} margin={{ top: 10, right: 20, left: 0, bottom: 20 }}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis
                          dataKey="date"
                          tick={{ fontSize: 10 }}
                          minTickGap={20}
                        />
                        <YAxis
                          tick={{ fontSize: 10 }}
                          domain={["auto", "auto"]}
                          label={{
                            value: "SPI",
                            angle: -90,
                            position: "insideLeft",
                            offset: 10,
                          }}
                        />
                        <Tooltip />
                        <ReferenceLine y={0} stroke="#999" strokeDasharray="3 3" />
                        <Line
                          type="monotone"
                          dataKey="spi"
                          dot={false}
                          strokeWidth={2}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>

                  <div className="table-wrapper">
                    <table className="history-table">
                      <thead>
                        <tr>
                          <th>Дата</th>
                          <th>SPI</th>
                        </tr>
                      </thead>
                      <tbody>
                        {historyData.map((row) => (
                          <tr key={row.date}>
                            <td>{row.date}</td>
                            <td>{row.spi.toFixed ? row.spi.toFixed(2) : row.spi}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </>
              )}
            </section>
          </>
        )}
      </main>
    </div>
  );
}

export default App;
